# App Shortcuts (Supernote plugin)

Adds your sideloaded apps to the context menu (text selection menu) of the native Supernote document reader.

Select text in a document, tap an app's button, and the selected text is sent to that app.

## Popup behavior

For each app the plugin tries, in order:

1. **`ACTION_PROCESS_TEXT`**: apps that support Android's text-processing action (Google Translate, dictionaries, etc.) open as a small popup, like in Moon+ Reader.
2. **`ACTION_SEND`**: apps that accept shared text open full screen or in split view with the text.
3. **Plain launch**: any other app is just opened.

In the picker, apps that support option 1 are marked `(popup)`.

## Usage

1. Tap the **App shortcuts** button in the toolbar.
2. Pick up to 6 apps and tap **Sačuvaj** (Save).
3. Close and reopen the document, then select some text. Your apps show up in the context menu.

The settings screen is in Serbian: *Zatvori* = Close, *Sačuvaj* = Save.

## Privacy

- No network code and no plugin permissions requested.
- It lists your installed launcher apps only so you can pick which ones to add.
- An app is launched only when you tap its button. The selected text goes only to that app.
- Your choices are stored in a `shortcuts.json` file in the plugin's own directory.

## Install

Download the `.snplg` from Releases (or build it yourself), copy it to `MyStyle` on the device, then go to Settings > Apps > Plugins > Add Plugin.

## Build

Requires Node 18+, JDK 17, Android SDK, and `zip`.

```bash
npm install
./buildPlugin.sh        # Windows: .\buildPlugin.ps1
```

The result is in `build/outputs/`. You can also run the **Build plugin** GitHub Action manually and download the artifact.

## How it works

- `index.js` registers the toolbar button and the per-app selection-menu buttons synchronously at startup (this matters: late registration was not picked up by the host).
- `src/bridge.ts` handles button presses and reads the selected text via `PluginDocAPI.getLastSelectedText()`.
- `src/shortcuts.ts` stores/loads the config and registers the buttons.
- `android/app/src/main/java/com/app_shortcuts/AppLauncherModule.kt` is a small native module (list apps, export icons, launch apps, read/write config).

## Disclaimer

This plugin was vibe-coded with Claude, using other verified Supernote plugins as a reference for the plugin patterns. It works for me, but there is no warranty and no liability if something breaks or interferes with other Supernote functions. Use at your own risk.

## License

The plugin code (`index.js`, `App.tsx`, `src/`, `AppLauncherModule.kt`, `AppLauncherPackage.kt`) is MIT licensed, see `LICENSE`. The rest is boilerplate from the official Supernote plugin template and React Native, which keep their own licenses. `sn-plugin-lib` is MIT.
