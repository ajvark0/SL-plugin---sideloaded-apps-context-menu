import { AppRegistry, Image } from 'react-native';
import App from './App';
import { name as appName } from './app.json';
import { PluginManager } from 'sn-plugin-lib';
import { installBridge, startShortcuts, SETUP_ID } from './src/bridge';

AppRegistry.registerComponent(appName, () => App);
PluginManager.init();

// Sve se registruje ODMAH i sinhrono, kao u dokumentaciji.
const icon = Image.resolveAssetSource(require('./assets/icon.png')).uri;

// Toolbar: podešavanje (biraš aplikacije)
PluginManager.registerButton(1, ['NOTE', 'DOC'], {
  id: SETUP_ID,
  name: 'App shortcuts',
  icon,
  showType: 1,
});

// Dugmad izabranih aplikacija u selection meniju (DOC)
startShortcuts();
installBridge();
