import { PluginManager, PluginDocAPI } from 'sn-plugin-lib';
import {
  BASE_ID, MAX_SHORTCUTS, SETUP_ID, Shortcut,
  launchApp, loadShortcuts, loadShortcutsSync, registerSlots, registerSlotsNow,
} from './shortcuts';

export { SETUP_ID };

let slots: Shortcut[] = [];
let pending = false;
let subscriber: (() => void) | null = null;

export function setSlots(list: Shortcut[]) { slots = list; }

/** Poziva se iz index.js odmah nakon registerButton za toolbar dugme. */
export function startShortcuts() {
  const now = loadShortcutsSync();
  if (now.length) {
    slots = now;
    registerSlotsNow(now);       // sinhrono, kao WebLookup
    return;
  }
  // rezerva: ako sinhrono čitanje ne uspije, učitaj asinhrono
  loadShortcuts().then(list => {
    slots = list;
    if (list.length) registerSlots(list, false);
  });
}

export function installBridge() {
  PluginManager.registerButtonListener({
    onButtonPress: async (event: any) => {
      const id: number = event?.id;
      if (id === SETUP_ID) {
        if (subscriber) subscriber(); else pending = true;
        return;
      }
      const idx = id - BASE_ID;
      if (idx < 0 || idx >= MAX_SHORTCUTS) return;
      if (!slots.length) slots = await loadShortcuts();
      const s = slots[idx];
      if (!s) return;
      let text = '';
      try {
        const r: any = await PluginDocAPI.getLastSelectedText();
        if (r?.success && r.result) text = r.result;
      } catch {}
      launchApp(s.pkg, text);
    },
  } as any);
}

export function takePending(): boolean {
  const p = pending;
  pending = false;
  return p;
}

export function onSetupPress(cb: () => void) {
  subscriber = cb;
  return () => { if (subscriber === cb) subscriber = null; };
}
