import { NativeModules } from 'react-native';
import { PluginManager } from 'sn-plugin-lib';

const { AppLauncher, SourceCode } = NativeModules;

export const SETUP_ID = 100;
export const BASE_ID = 300;       // slot dugmad: 300..305
export const MAX_SHORTCUTS = 6;
export const SHOW_TYPE = 0;       // 0 = bez UI-ja; ako se dugmad ne pojave, probaj 1

export type Shortcut = { pkg: string; label: string; icon: string };
export type InstalledApp = { pkg: string; label: string; popup?: boolean };

/** Folder plugina odmah (sinhrono), iz putanje JS bundla. */
export function pluginDirSync(): string | null {
  try {
    const url: string = SourceCode?.scriptURL ?? '';
    const p = url.replace(/^file:\/\//, '');
    const i = p.lastIndexOf('/');
    return p.startsWith('/') && i > 0 ? p.slice(0, i) : null;
  } catch {
    return null;
  }
}

async function dirAsync(): Promise<string> {
  const d = await PluginManager.getPluginDirPath();
  if (!d) throw new Error('Plugin dir not available');
  return d;
}

export function loadShortcutsSync(): Shortcut[] {
  try {
    const d = pluginDirSync();
    if (!d) return [];
    const txt: string | null = AppLauncher.readTextSync(`${d}/shortcuts.json`);
    return txt ? JSON.parse(txt) : [];
  } catch {
    return [];
  }
}

export async function loadShortcuts(): Promise<Shortcut[]> {
  try {
    const txt: string | null = await AppLauncher.readText(`${await dirAsync()}/shortcuts.json`);
    return txt ? JSON.parse(txt) : [];
  } catch {
    return [];
  }
}

export async function saveShortcuts(list: Shortcut[]): Promise<void> {
  const json = JSON.stringify(list);
  await AppLauncher.writeText(`${await dirAsync()}/shortcuts.json`, json);
  // isto u folder koji se vidi sinhrono (ako je različit)
  const sd = pluginDirSync();
  if (sd) { try { await AppLauncher.writeText(`${sd}/shortcuts.json`, json); } catch {} }
}

export async function exportIcon(pkg: string): Promise<string> {
  return AppLauncher.exportIcon(pkg, `${await dirAsync()}/icons/${pkg}.png`);
}

export async function listInstalledApps(): Promise<InstalledApp[]> {
  return AppLauncher.getLaunchableApps();
}

export function launchApp(pkg: string, text: string) {
  AppLauncher.launch(pkg, text);
}

function btn(i: number, s: Shortcut) {
  return PluginManager.registerButton(3, ['DOC'], {
    id: BASE_ID + i, name: s.label, icon: s.icon, showType: SHOW_TYPE,
  } as any);
}

/** Registracija BEZ čekanja (poziva se sinhrono pri pokretanju plugina). */
export function registerSlotsNow(list: Shortcut[]) {
  list.slice(0, MAX_SHORTCUTS).forEach((s, i) => {
    try { Promise.resolve(btn(i, s)).catch(() => {}); } catch {}
  });
}

/** Ponovna registracija (nakon izmjene izbora). Vraća log. */
export async function registerSlots(list: Shortcut[], unregisterFirst: boolean): Promise<string[]> {
  const log: string[] = [];
  if (unregisterFirst) {
    for (let i = 0; i < MAX_SHORTCUTS; i++) {
      try { await PluginManager.unregisterButton(BASE_ID + i); } catch {}
    }
  }
  for (let i = 0; i < Math.min(list.length, MAX_SHORTCUTS); i++) {
    try {
      const ok = await btn(i, list[i]);
      log.push(`${list[i].label}: ${ok}`);
    } catch (e: any) {
      log.push(`${list[i].label} GRESKA: ${e?.message ?? e}`);
    }
  }
  return log;
}
